FooCoin (FOO)
===========

[![Build Status](https://travis-ci.org/RazorLove/foocoin.png?branch=master)](https://travis-ci.org/RazorLove/foocoin)


Scrypt Hashcash PoW Template